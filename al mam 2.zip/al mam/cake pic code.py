import pygame
import random as rd
import time
from pygame import mixer

#SCREEN SET-UP
win = pygame.display.set_mode((600,700))
pygame.display.set_caption("congratulations on completing another round around the sun..🥳🎂🥳🎂🥳")


#SONG PLAYING
mixer.init()
mixer.music.load("uff.mp3")
mixer.music.set_volume(100.5) 
mixer.music.play()

#CAKE1
y = 800
p = pygame.image.load("boyscake.jpg")
for i in range(112):
    clr = (0, 0, 0)
    win.fill(clr)
    win.blit(p, (10,y))
    time.sleep(0.1)
    y -= 10

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            quit()

    pygame.display.update()
    
#CAKE2
y = 300
p = pygame.image.load("carcake.jpg")
for i in range(80):
    clr = (0, 0, 0)
    win.fill(clr)
    win.blit(p, (10,y))
    time.sleep(0.1)
    y -= 10
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            quit()

    pygame.display.update()

#pic1
y = 300
p = pygame.image.load("p2.jpg")
for i in range(80):
    clr = (0, 0, 0)
    win.fill(clr)
    win.blit(p, (10,y))
    time.sleep(0.1)
    y -= 10
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            quit()

    pygame.display.update()

#cake3
y = 300
p = pygame.image.load("footballcake.webp")
for i in range(80):
    clr = (0, 0, 0)
    win.fill(clr)
    win.blit(p, (10,y))
    time.sleep(0.1)
    y -= 10
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            quit()

    pygame.display.update()

#cake4
y = 300
p = pygame.image.load("gemscake.webp")
for i in range(80):
    clr = (0, 0, 0)
    win.fill(clr)
    win.blit(p, (10,y))
    time.sleep(0.1)
    y -= 10
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            quit()

    pygame.display.update()

#PIC2
y = 300
p = pygame.image.load("p3.jpg")
for i in range(80):
    clr = (0, 0, 0)
    win.fill(clr)
    win.blit(p, (10,y))
    time.sleep(0.1)
    y -= 10
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            quit()

    pygame.display.update()

#CAKE5
y = 300
p = pygame.image.load("girlcake.jpg")
for i in range(80):
    clr = (0, 0, 0)
    win.fill(clr)
    win.blit(p, (10,y))
    time.sleep(0.1)
    y -= 10
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            quit()

    pygame.display.update()

#CAKE6
y = 300
p = pygame.image.load("pinkcake.jpg")
for i in range(80):
    clr = (0, 0, 0)
    win.fill(clr)
    win.blit(p, (10,y))
    time.sleep(0.1)
    y -= 10
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            quit()

    pygame.display.update()

#PIC3
y = 300
p = pygame.image.load("p4.jpg")
for i in range(80):
    clr = (0, 0, 0)
    win.fill(clr)
    win.blit(p, (10,y))
    time.sleep(0.1)
    y -= 10
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            quit()

    pygame.display.update()

#CAKE7
y = 300
p = pygame.image.load("princess cake.jpg")
for i in range(80):
    clr = (0, 0, 0)
    win.fill(clr)
    win.blit(p, (10,y))
    time.sleep(0.1)
    y -= 10
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            quit()

    pygame.display.update()


#CAKE8
y = 300
p = pygame.image.load("tomjerrycake.jpg")
for i in range(80):
    clr = (0, 0, 0)
    win.fill(clr)
    win.blit(p, (10,y))
    time.sleep(0.1)
    y -= 10
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            quit()

    pygame.display.update()

#PIC4
y = 300
p = pygame.image.load("p7.jpg")
for i in range(80):
    clr = (0, 0, 0)
    win.fill(clr)
    win.blit(p, (10,y))
    time.sleep(0.1)
    y -= 10
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            quit()

    pygame.display.update()

#CAKE9
y = 300
p = pygame.image.load("sprinkle.jpg")
for i in range(80):
    clr = (0, 0, 0)
    win.fill(clr)
    win.blit(p, (10,y))
    time.sleep(0.1)
    y -= 10
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            quit()

    pygame.display.update()

#CAKE10
y = 300
p = pygame.image.load("c1.jpg")
for i in range(80):
    clr = (0, 0, 0)
    win.fill(clr)
    win.blit(p, (10,y))
    time.sleep(0.1)
    y -= 10
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            quit()

    pygame.display.update()

#PIC4
y = 300
p = pygame.image.load("p8.jpg")
for i in range(80):
    clr = (0, 0, 0)
    win.fill(clr)
    win.blit(p, (10,y))
    time.sleep(0.1)
    y -= 10
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            quit()

    pygame.display.update()

#CAKE11
y = 300
p = pygame.image.load("c2.jpg")
for i in range(80):
    clr = (0, 0, 0)
    win.fill(clr)
    win.blit(p, (10,y))
    time.sleep(0.1)
    y -= 10
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            quit()

    pygame.display.update()

#CAKE12
y = 300
p = pygame.image.load("c3.webp")
for i in range(80):
    clr = (0, 0, 0)
    win.fill(clr)
    win.blit(p, (10,y))
    time.sleep(0.1)
    y -= 10
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            quit()

    pygame.display.update()

#PIC5
y = 300
p = pygame.image.load("p9.jpg")
for i in range(80):
    clr = (0, 0, 0)
    win.fill(clr)
    win.blit(p, (10,y))
    time.sleep(0.1)
    y -= 10
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            quit()

    pygame.display.update()

#CAKE13
y = 300
p = pygame.image.load("c4.jpg")
for i in range(80):
    clr = (0, 0, 0)
    win.fill(clr)
    win.blit(p, (10,y))
    time.sleep(0.1)
    y -= 10
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            quit()

    pygame.display.update()

#CAKE14
y = 300
p = pygame.image.load("c5.jpg")
for i in range(80):
    clr = (0, 0, 0)
    win.fill(clr)
    win.blit(p, (10,y))
    time.sleep(0.1)
    y -= 10
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            quit()

    pygame.display.update()

#COLLAGE1
y = 300
p = pygame.image.load("collage.jpg")
for i in range(80):
    clr = (0, 0, 0)
    win.fill(clr)
    win.blit(p, (10,y))
    time.sleep(0.1)
    y -= 10
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            quit()

    pygame.display.update()


#CAKE15
y = 300
p = pygame.image.load("c6.jpg")
for i in range(80):
    clr = (0, 0, 0)
    win.fill(clr)
    win.blit(p, (10,y))
    time.sleep(0.1)
    y -= 10
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            quit()

    pygame.display.update()

#CAKE16
y = 300
p = pygame.image.load("c7.jpg")
for i in range(80):
    clr = (0, 0, 0)
    win.fill(clr)
    win.blit(p, (10,y))
    time.sleep(0.1)
    y -= 10
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            quit()

    pygame.display.update()

#COLLAGE2
y = 300
p = pygame.image.load("collage2.png")
for i in range(80):
    clr = (0, 0, 0)
    win.fill(clr)
    win.blit(p, (10,y))
    time.sleep(0.1)
    y -= 10
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            quit()

    pygame.display.update()


#CAKE17
y = 300
p = pygame.image.load("c8.jpg")
for i in range(80):
    clr = (0, 0, 0)
    win.fill(clr)
    win.blit(p, (10,y))
    time.sleep(0.1)
    y -= 10
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            quit()

    pygame.display.update()


#CAKE18
y = 300
p = pygame.image.load("c9.jpg")
for i in range(80):
    clr = (0, 0, 0)
    win.fill(clr)
    win.blit(p, (10,y))
    time.sleep(0.1)
    y -= 10
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            quit()

    pygame.display.update()

#Collage3
y = 300
p = pygame.image.load("collage3.png")
for i in range(80):
    clr = (0, 0, 0)
    win.fill(clr)
    win.blit(p, (10,y))
    time.sleep(0.1)
    y -= 10
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            quit()

    pygame.display.update()


#CAKE19
y = 300
p = pygame.image.load("c10.jpg")
for i in range(80):
    clr = (0, 0, 0)
    win.fill(clr)
    win.blit(p, (10,y))
    time.sleep(0.1)
    y -= 10
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            quit()

    pygame.display.update()

#COLLAGE4
y = 300
p = pygame.image.load("collage4.jpg")
for i in range(80):
    clr = (0, 0, 0)
    win.fill(clr)
    win.blit(p, (10,y))
    time.sleep(0.1)
    y -= 10
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            quit()

    pygame.display.update()


#song stop
mixer.music.stop()
